import random

word_list=['apple','banana','cartoon','elephant']
chosen_word= random.choice(word_list) 

length=len(chosen_word)

display=[]
for _ in range(length):
    display+='_'
print(display)  

end_of_game=False

while not end_of_game:
    guess=input("Guess a letter: ").lower()

    for position in range(length):
        letter=chosen_word[position]
        if letter == guess:
            display[position]=guess

    print(display)

    if "_" not in display:
        end_of_game=True
        print ("you win")

